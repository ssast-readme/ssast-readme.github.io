/**
 * 接口域名的管理
 */
const base = {
	baseURL: 'http://1.15.15.73:13900'
}

export default base;
