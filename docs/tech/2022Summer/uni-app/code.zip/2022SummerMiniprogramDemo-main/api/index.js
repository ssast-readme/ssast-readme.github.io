import person_api from "@/api/person_api.js"

export default {
	person_api
};
