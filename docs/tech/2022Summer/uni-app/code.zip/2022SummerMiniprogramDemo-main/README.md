# 2022SummerMiniprogramDemo
本项目为2022年软院科协暑期培训课程——基于uni-app框架的微信小程序开发。

由于作者水平有限，如有错误，还请读者不吝赐教。联系邮箱为：yang-jh19@mails.tsinghua.edu.cn
