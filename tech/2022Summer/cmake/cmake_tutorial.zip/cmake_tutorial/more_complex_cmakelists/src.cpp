#include <iostream>
#include "head.h"
void log(const char* _log_str) {
#ifdef DEBUG
    std::cout << _log_str << std::endl;
#endif
}
int main() {
    std::cout << "hello world" << std::endl;
#ifdef LINUX
    std::cout << "hello linux" << std::endl;
    foo();
#endif
    log("hello debug");
}