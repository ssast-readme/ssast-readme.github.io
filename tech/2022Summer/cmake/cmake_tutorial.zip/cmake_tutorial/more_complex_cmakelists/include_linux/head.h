void foo(){
    std::cout << "foo" << std::endl;
}