echo "RUNNING HELLO"
# install dependencies if any
# check updates if any
# any other things if you want
hello