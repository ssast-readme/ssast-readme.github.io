#include <iostream>

int main(){
    std::cout << "hello project" << std::endl;
}