# CMake

**多看文档！！**

## 什么是CMake

CMake是一种开源的、跨平台友好的编译配置工具，同时也支持测试、安装部署等功能。

当同时使用不同的语言、编译器开发一个项目，并/或要将其跨平台编译时，使用CMake可以统一和简化编译过程。

官方网站是 [www.cmake.org](http://www.CMake.org/)，可以通过访问官方网站获得更多关于 CMake 的信息

在较大的项目中，使用CMake可以极大简化项目管理和编译时的配置工作。

## CMake安装

如果系统没有安装CMake，可以

1. [http://www.cmake.org/HTML/Download.htm](http://www.CMake.org/HTML/Download.html)  下载安装

2. 使用包管理器安装

- For Debian and Ubuntu, use `apt install cmake`
- For Windows, use `choco install cmake` (带货：chocolatey真的很好用~~，每个使用Windows的用户都应当安装~~)

3. 使用[源码]([Kitware/CMake: Mirror of CMake upstream repository (github.com)](https://github.com/Kitware/CMake))编译安装

## Hello, World

下面使用CMake完成一个简单的HelloWorld程序的编译。

1. 写一个`Hello, World`

```cpp
#src.cpp

#include <iostream>
int main(){
	std::cout <<  "hello world" << std::endl;
}
```

2. 写`CMakeLists.txt`

```cmake
#CMakeLists.txt

PROJECT (HELLOWORLD)
SET(SRC_LIST src.cpp)
MESSAGE(STATUS "This is BINARY dir " ${HELLOWORLD_BINARY_DIR})
MESSAGE(STATUS "This is SOURCE dir " ${HELLOWORLD_SOURCE_DIR})
ADD_EXECUTABLE(hello ${SRC_LIST})
```

3. 步骤三、使用CMake，生成makefile

```cpp
cmake .

=========
[root@localhost CMake]# CMake .
CMake Warning (dev) in CMakeLists.txt:
  Syntax Warning in CMake code at

    /root/CMake/CMakeLists.txt:7:37

  Argument not separated from preceding token by whitespace.
This warning is for project developers.  Use -Wno-dev to suppress it.

-- The C compiler identification is GNU 10.2.1
-- The CXX compiler identification is GNU 10.2.1
-- Check for working C compiler: /usr/bin/cc
-- Check for working C compiler: /usr/bin/cc -- works
-- Detecting C compiler ABI info
-- Detecting C compiler ABI info - done
-- Check for working CXX compiler: /usr/bin/c++
-- Check for working CXX compiler: /usr/bin/c++ -- works
-- Detecting CXX compiler ABI info
-- Detecting CXX compiler ABI info - done
-- This is BINARY dir /root/CMake
-- This is SOURCE dir /root/CMake
-- Configuring done
-- Generating done
-- Build files have been written to: /root/CMake
```

目录下就生成了`CMakeFiles, CMakeCache.txt, CMake_install.CMake` 等文件，并且生成了`Makefile`.

4. make

```cpp
root@localhost CMake]# make
Scanning dependencies of target hello
[100%] Building CXX object CMakeFiles/hello.dir/main.cpp.o
Linking CXX executable hello
[100%] Built target hello
```

5. 获得可执行文件

## CMakeLists是什么？

让我们仔细看一看这个文件。

### PROJECT关键字

可以用来指定工程的名字和支持的语言，默认支持所有语言

`PROJECT (HELLO)`				指定了工程的名字，并且支持所有语言

`PROJECT (HELLO CXX)`		指定了工程的名字，并且支持语言是C++

`PROJECT (HELLO C CXX)`	指定了工程的名字，并且支持语言是C和C++

该指定隐式定义了两个CMake的变量

`<projectname>_BINARY_DIR`，本例中是 `HELLO_BINARY_DIR`

`<projectname>_SOURCE_DIR`，本例中是 `HELLO_SOURCE_DIR`

`MESSAGE`关键字就可以直接使用者两个变量，当前都指向当前的工作目录，后面会讲外部编译

问题：如果改了工程名，这两个变量名也会改变

解决：又定义两个预定义变量：PROJECT_BINARY_DIR和PROJECT_SOURCE_DIR，这两个变量和HELLO_BINARY_DIR，HELLO_SOURCE_DIR是一致的。所以改了工程名也没有关系

### SET关键字

变量定义和赋值语句

`SET(SRC_LIST main.cpp)`    `SRC_LIST`变量就包含了`main.cpp`

也可以`SET(SRC_LIST main.cpp t1.cpp t2.cpp)`

### MESSAGE关键字

向终端输出用户自定义的信息

主要包含三种信息：

- `SEND_ERROR`，产生错误，生成过程被跳过。
- `SATUS`，输出前缀为`—`的信息。
- `FATAL_ERROR`，立即终止所有 CMake 过程.

### ADD_EXECUTABLE关键字

生成可执行文件

`ADD_EXECUTABLE(hello ${SRC_LIST})`     生成的可执行文件名是hello，源文件读取变量`SRC_LIST`中的内容

`ADD_EXECUTABLE(hello main.cpp)`

上述例子可以简化的写成

```cmake
PROJECT(HELLO)
ADD_EXECUTABLE(hello main.cpp)
```

注意：工程名的`HELLO`和生成的可执行文件`hello`没有任何关系

### 语法的基本原则

- 变量使用`${}`方式取值，但是在`IF`系列条件控制语句中是直接使用变量名
- 指令(参数 1 参数 2...) 参数放在括号内，参数之间使用空格或分号分开。 以上面的`ADD_EXECUTABLE`指令为例，如果存在另外一个 func.cpp 源文件，就要写成：`ADD_EXECUTABLE(hello main.cpp func.cpp)`或者`ADD_EXECUTABLE(hello main.cpp func.cpp)`
  
- 指令是大小写不敏感的，参数和变量是大小写相关的。通常，习惯全部使用大写指令。

- `SET(SRC_LIST src.cpp)`可以写成`SET(SRC_LIST “src.cpp”)`，当源文件名中含有空格必须要加双引号
- `ADD_EXECUTABLE(hello src)`后缀可以不写，CMake会自动定位`.c`和`.cpp`，但当存在可执行文件main和源文件main.[c|cpp]时，可能产生混乱

## 内部构建和外部构建

- 上述例子就是内部构建，会产生大量临时文件，清理不方便
- 可以考虑新建一个build文件夹，在其内构建

### 外部构建方式举例

1. 建立一个build目录，可以在任何地方，建议在当前目录下

2. 在build下`cmake ..` or `cmake <CMakeLists的绝对路径>`，即可在build目录下产生所有文件

3. 在build下make

注意上一步中的两个变量

1、`HELLO_SOURCE_DIR`还是原来的工程路径

2、`HELLO_BINARY_DIR`编译路径 也就是 `.<CMakeLists路径>/bulid`


## 更加复杂的CMakeLists

考虑不同平台有不同的依赖库、有时会有Debug输出要求、针对不同编译器需要某些特定行为的情形，比如下面的例子

有以下的cpp文件
```cpp
#include <iostream>
#include "head.h"
void log(const char* _log_str) {
#ifdef DEBUG
    std::cout << _log_str << std::endl;
#endif
}
int main() {
    std::cout << "hello world" << std::endl;
#ifdef LINUX
    std::cout << "hello linux" << std::endl;
    foo();
#endif
    log("hello debug");
}
```
我们编写以下的cmakelists

```cmake
CMAKE_MINIMUM_REQUIRED(VERSION 3.23)
PROJECT (HELLOWORLD)
SET(SRC_LIST src.cpp)
MESSAGE(STATUS "This is BINARY dir " ${HELLOWORLD_BINARY_DIR})
MESSAGE(STATUS "OS is " ${CMAKE_SYSTEM})
IF(DEBUG)
    ADD_DEFINITIONS(-DDEBUG)
ENDIF(DEBUG)
IF(UNIX AND NOT APPLE)
    SET(LINUX TRUE)
    MESSAGE(STATUS "BUILD ON LINUX")
    INCLUDE_DIRECTORIES(BEFORE include_linux)
    ADD_DEFINITIONS(-DLINUX)
ELSEIF(WIN32)
    # do something
    IF(MSVC)
        IF(MSVC10)
        # do something
        ENDIF(MSVC10)
        # do other things
    ENDIF(MSVC)
    # do something
ELSEIF(APPLE)
	IF(DEBUG)
        SET(CMAKE_BUILD_TYPE "Debug")
        SET(CMAKE_CXX_FLAGS_DEBUG "$ENV{CXXFLAGS} -O0 -Wall -g -ggdb")
        SET(CMAKE_CXX_FLAGS_RELEASE "$ENV{CXXFLAGS} -O3 -Wall")
	ENDIF(DEBUG)
    # do something
ELSE()
    # do something
ENDIF(UNIX AND NOT APPLE)

MESSAGE(STATUS "This is SOURCE dir " ${HELLOWORLD_SOURCE_DIR})
ADD_EXECUTABLE(hello ${SRC_LIST})
```

## Hello World工程化

### 将目标文件放入构建目录的 bin 子目录

每个目录下都要有一个CMakeLists.txt说明

```cpp
.
├── build
├── CMakeLists.txt
└── src
    ├── CMakeLists.txt
    └── main.cpp
```

外层CMakeLists.txt

```cmake
PROJECT(HELLOPROJECT)
ADD_SUBDIRECTORY(src bin)
```

src下的CMakeLists.txt

```cmake
ADD_EXECUTABLE(hello main.cpp)
```

### ADD_SUBDIRECTORY 指令

`ADD_SUBDIRECTORY(source_dir [binary_dir] [EXCLUDE_FROM_ALL])`

- 这个指令用于向当前工程添加存放源文件的子目录，并可以指定中间二进制和目标二进制存放的位置
- EXCLUDE_FROM_ALL函数是将写的目录从编译中排除，如程序中的example
- ADD_SUBDIRECTORY(src bin)
  
    将 src 子目录加入工程并指定编译输出(包含编译中间结果)路径为bin 目录
    
    如果不进行 bin 目录的指定，那么编译结果(包括中间结果)都将存放在build/src 目录
    

### 更改二进制的保存路径

SET 指令重新定义 EXECUTABLE_OUTPUT_PATH 和 LIBRARY_OUTPUT_PATH 变量 来指定最终的目标二进制的位置
```cmake
SET(EXECUTABLE_OUTPUT_PATH ${PROJECT_BINARY_DIR}/bin)
SET(LIBRARY_OUTPUT_PATH ${PROJECT_BINARY_DIR}/lib)
```


## 让Hello World变为可安装的软件

### 安装

- 一种是从代码编译后直接 make install 安装
- 一种是打包时的指定目录安装。
  - 一种方式是：make install DESTDIR=/tmp/test
  - 同时也可以：./configure –prefix=/usr

为了使我们的项目成为一个可安装的软件，需要用到CMake指令：INSTALL

INSTALL的安装可以包括：二进制、动态库、静态库以及文件、目录、脚本等

在一个完整的工程实践中，我们期望

- 有一个子目录 src，放置工程源代码
- 添加一个子目录 doc，放置这个工程的文档
- 工程中存在文本文件 COPYRIGHT, README
- 工程中存在入口脚本 [runhello.sh](http://runhello.sh/) ，用来调用 hello 二进制（以及前置和后续工作）
- 将构建的目标文件放入构建目录的 bin 子目录
- 将 doc 目录的内容以及 COPYRIGHT/README 安装到/usr/share/doc/cmake/
- 将可执行文件放入（或链接至）/usr/local/bin/，使用户可以简单地调用

例如，一个简单但完整的工程可能是下面这个样子的。

```cpp
.
├── CMakeLists.txt
├── COPYRIGHT
├── README
├── build
├── doc
│   └── how_to_use.txt
├── runhello.sh
└── src
    ├── CMakeLists.txt
    └── src.cpp

3 directories, 7 files
```

### 安装可执行文件

`INSTALL(TARGETS hello RUNTIME DESTINATION bin)  `

同时，也可以有下面的写法

### 安装文件COPYRIGHT和README

`INSTALL(FILES COPYRIGHT README DESTINATION share/doc/cmake/)`

FILES：表明安装的为文件

DESTINATION：

1、写绝对路径

2、如果写相对路径，实际路径是：`${CMake_INSTALL_PREFIX}/<DESTINATION 定义的路径>`

`CMake_INSTALL_PREFIX `默认为 `/usr/local/`

### 安装脚本runhello.sh

PROGRAMS：非目标文件的可执行程序安装(比如脚本之类)

`INSTALL(PROGRAMS runhello.sh DESTINATION bin)`

实际安装到的是 `/usr/local/bin/`

### 如何安装

```bash
cmake ..
make
make install
```
